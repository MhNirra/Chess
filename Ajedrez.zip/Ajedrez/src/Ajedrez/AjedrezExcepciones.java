package Ajedrez;

public class AjedrezExcepciones extends TablaExcepciones {/*herencia del archivo TablaExcepciones*/

    public AjedrezExcepciones(String msg){ /*imprime el mensaje dejado en los archivos*/
        super(msg);
    }

}