package Ajedrez;

public class TablaExcepciones extends RuntimeException {

    public TablaExcepciones(String msg){
        super(msg);
    }
}
