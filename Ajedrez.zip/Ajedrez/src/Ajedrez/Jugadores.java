package Ajedrez;
/*Creamos los jugadores*/
public enum Jugadores {
    JUGADOR_N2,
    JUGADOR_N1;
}
